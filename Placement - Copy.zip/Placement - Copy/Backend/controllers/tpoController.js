const TPO = require("../models/TPO");
const User = require("../models/User");
const Student = require("../models/Student");
const Company = require("../models/Company");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

// ✅ Middleware to Ensure Only One TPO Exists
const ensureSingleTPO = async () => {
  const existingTPO = await TPO.findOne();
  if (existingTPO) {
    throw new Error("Only one TPO is allowed.");
  }
};


// ✅ Add Company & Schedule (Ensure All Students Can See It)
exports.addCompanyAndSchedule = async (req, res) => {
  try {
    const { name, email, password, scheduleDate, scheduleEvent } = req.body;

    // ✅ Validate required fields
    if (!name || !email || !password || !scheduleDate || !scheduleEvent) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    // ✅ Check if email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already registered" });
    }

    // ✅ Hash password securely
    const hashedPassword = await bcrypt.hash(password, 10);

    // ✅ Create User Entry in User Collection
    const user = new User({ name, email, password: hashedPassword, role: "company" });
    await user.save();

    // ✅ Create Company Entry with Schedule
    const company = new Company({
      userId: user._id,
      name,
      email,
      schedule: { date: scheduleDate, event: scheduleEvent }
    });
    await company.save();

    res.status(201).json({
      success: true,
      message: "Company & Schedule added successfully.",
      company
    });

  } catch (error) {
    console.error("❌ Error:", error);
    res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
  }
};

// ✅ Update Company Details
exports.updateCompany = async (req, res) => {
  try {
    const { companyId, name, email, password, scheduleDate, scheduleEvent } = req.body;

    // ✅ Find the company
    const company = await Company.findById(companyId);
    if (!company) return res.status(404).json({ message: "Company not found" });

    // ✅ Update all fields in the Company collection
    company.name = name || company.name;
    company.email = email || company.email;
    if (password) {
      company.password = await bcrypt.hash(password, 10);
    }
    if (scheduleDate) company.schedule.date = scheduleDate;
    if (scheduleEvent) company.schedule.event = scheduleEvent;
    await company.save();

    // ✅ Update only Name, Schedule Date, and Event in Student Collection
    await Student.updateMany(
      { "schedule.companyId": companyId },
      {
        $set: {
          "schedule.$.companyName": name,
          "schedule.$.date": scheduleDate,
          "schedule.$.event": scheduleEvent
        }
      }
    );

    res.json({ message: "Company updated successfully, and students' schedules updated" });
  } catch (error) {
    console.error("❌ Error updating company:", error);
    res.status(500).json({ message: "Internal Server Error", error: error.message });
  }
};
// ✅ Send Notification to Students
exports.notifyStudents = async (req, res) => {
  try {
    let { studentIds, message } = req.body;

    if (!studentIds || !Array.isArray(studentIds) || studentIds.length === 0) {
      return res.status(400).json({ message: "At least one student ID is required." });
    }

    await Student.updateMany(
      { _id: { $in: studentIds } },
      { $push: { notifications: { message, date: new Date() } } }
    );

    res.json({ message: "Notifications sent successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Block or Unblock a Student
exports.blockUnblockStudent = async (req, res) => {
  try {
    const { studentId, action } = req.body; // action: "block" or "unblock"
    const student = await Student.findById(studentId);

    if (!student) return res.status(404).json({ message: "Student not found" });

    student.blocked = action === "block";
    await student.save();

    res.json({ message: `Student successfully ${action}ed.` });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Delete Student
exports.deleteStudent = async (req, res) => {
  try {
    const { studentId } = req.body;
    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ message: "Student not found" });

    await Student.findByIdAndDelete(studentId);
    await Company.updateMany({}, { $pull: { students: { studentId } } });

    res.json({ message: "Student deleted successfully and removed from companies." });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Delete Company
exports.deleteCompany = async (req, res) => {
  try {
    const { companyId } = req.body;

    await Company.findByIdAndDelete(companyId);
    await Student.updateMany({}, { $pull: { schedule: { companyId } } });

    res.json({ message: "Company deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Filter Students by Aggregate
exports.filterStudents = async (req, res) => {
  try {
    const { minAggregate } = req.body;
    const students = await Student.find({ aggregate: { $gte: minAggregate }, blocked: false });

    res.json({ students });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Get All Unblocked Students
exports.getAllStudents = async (req, res) => {
  try {
    const students = await Student.find({ blocked: false }, "-password");
    res.json({ success: true, students });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch students", error: error.message });
  }
};

// ✅ Get All Companies
exports.getAllCompanies = async (req, res) => {
  try {
    const companies = await Company.find();
    res.json({ success: true, companies });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch companies", error: error.message });
  }
};

// ✅ Add Placed Student's Photo & Package
exports.addPlacedStudent = async (req, res) => {
  try {
    const { studentId, packageAmount, companyName, jobRole, photoUrl } = req.body;

    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ message: "Student not found" });

    // ✅ Add Placement Details
    student.placement = {
      companyName,
      jobRole,
      packageAmount,
      photoUrl,  // URL of student's placement photo
      datePlaced: new Date()
    };

    await student.save();

    res.json({ success: true, message: "Placement details added successfully.", student });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to add placement details", error: error.message });
  }
};
