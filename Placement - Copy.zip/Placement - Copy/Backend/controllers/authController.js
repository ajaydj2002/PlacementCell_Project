const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Student = require("../models/Student");
const Company = require("../models/Company");
const TPO = require("../models/TPO");

const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: "1d" }
  );
};

// ✅ Register User (Ensures Only One TPO)
exports.register = async (req, res) => {
  try {
    const { name, email, password, role, mobile, address, tenthMarks, twelfthMarks } = req.body;
    let profilePic = req.file ? `/uploads/${req.file.filename}` : null; // Store only file path

    // ✅ Check if email is already registered
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "Email already exists" });

    // ✅ Ensure Only One TPO Can Register
    if (role === "tpo") {
      const existingTPO = await TPO.findOne();
      if (existingTPO) {
        return res.status(400).json({ message: "Only one TPO can register." });
      }
    }

    // ✅ Hash Password Before Storing
    const hashedPassword = await bcrypt.hash(password, 10);

    // ✅ Create & Save User
    const user = new User({ name, email, password: hashedPassword, role });
    await user.save();

    // ✅ Store in Respective Collection
    if (role === "student") {
      await new Student({
        userId: user._id,
        name,
        email,
        mobile,
        address,
        tenthMarks,
        twelfthMarks,
        profilePic
      }).save();
    } else if (role === "tpo") {
      await new TPO({
        userId: user._id,
        name,
        email,
        profilePic // TPO can also upload profile pic
      }).save();
    } else if (role === "company") {
      await new Company({
        userId: user._id,
        name,
        email
      }).save();
    }

    res.status(201).json({ message: `${role} registered successfully`, profilePic });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Login User (Student, TPO, Company)
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // ✅ Find User by Email
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // ✅ Validate Password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    // ✅ Generate JWT Token
    const token = generateToken(user);

    res.json({ message: "Login successful", token, user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
