const Company = require("../models/Company");
const Job = require("../models/Job");

// ✅ Add a Job and Save in `Jobs` Collection
exports.addJob = async (req, res) => {
  try {
    const { title, salary, location, jobDescription, jobType, recommendedSkills } = req.body;

    // ✅ Ensure `req.user.id` is valid
    console.log("Requesting User ID:", req.user.id);

    // ✅ Find the company using `userId`
    const company = await Company.findOne({ userId: req.user.id });

    if (!company) {
      console.log("❌ No company found for user:", req.user.id);
      return res.status(404).json({ success: false, message: "Company not found. Please ensure you are logged in as a company." });
    }

    console.log("✅ Found Company:", company.name);

    // ✅ Ensure `recommendedSkills` is always an array
    const skillsArray = Array.isArray(recommendedSkills) ? recommendedSkills : [];

    // ✅ Create a new Job document
    const newJob = new Job({
      companyId: company._id,
      companyName: company.name,  // ✅ Ensure companyName is correctly fetched
      title,
      salary,
      location,
      jobDescription,
      jobType,
      recommendedSkills: skillsArray
    });

    // ✅ Save job in the `Jobs` collection
    await newJob.save();
    console.log("✅ Job Saved Successfully:", newJob);

    res.json({ success: true, message: "Job added successfully", job: newJob });
  } catch (error) {
    console.error("❌ MongoDB Error:", error);
    res.status(500).json({ success: false, message: "Server error", error: error.message });
  }
};
