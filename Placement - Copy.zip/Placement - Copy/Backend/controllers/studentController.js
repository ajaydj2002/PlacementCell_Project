const Student = require("../models/Student");
const Company = require("../models/Company");
const Job = require("../models/Job"); // ✅ Import the Job model

// ✅ Add Skills & Aggregate
exports.addSkillsAndAggregate = async (req, res) => {
  try {
    const { skills, aggregate } = req.body;
    const student = await Student.findOne({ userId: req.user.id });

    if (!student) return res.status(404).json({ message: "Student not found" });

    student.skills = skills || student.skills;
    student.aggregate = aggregate || student.aggregate;
    await student.save();

    await Company.updateMany(
      { "students.studentId": student._id },
      { $set: { "students.$.skills": skills, "students.$.aggregate": aggregate } }
    );

    res.json({ message: "Skills & Aggregate updated successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ View All Schedules from All Companies
exports.viewSchedule = async (req, res) => {
  try {
    // ✅ Fetch all schedules from all companies
    const companies = await Company.find({}, "name schedule");

    let allSchedules = [];
    companies.forEach(company => {
      if (company.schedule) {
        allSchedules.push({
          companyName: company.name,
          date: company.schedule.date,
          event: company.schedule.event
        });
      }
    });

    if (allSchedules.length === 0) {
      return res.status(404).json({ message: "No schedules available." });
    }

    res.json({ success: true, schedules: allSchedules });
  } catch (error) {
    console.error("Error fetching schedules:", error);
    res.status(500).json({ message: error.message });
  }
};


// ✅ View All Jobs from All Companies
exports.viewJobs = async (req, res) => {
  try {
    // ✅ Fetch all jobs from `Jobs` collection
    const jobs = await Job.find({});

    console.log("All Jobs:", jobs); // ✅ Debugging

    if (!jobs || jobs.length === 0) {
      return res.status(404).json({ success: false, message: "No job postings available." });
    }

    res.json({ success: true, jobs });
  } catch (error) {
    console.error("Error fetching jobs:", error);
    res.status(500).json({ message: error.message });
  }
};

// ✅ Update Student Profile
exports.updateProfile = async (req, res) => {
  try {
    const { mobile, address, tenthMarks, twelfthMarks, skills, aggregate } = req.body;
    const profilePic = req.file ? req.file.path : null; // ✅ Handle profile picture upload

    const student = await Student.findOne({ userId: req.user.id });

    if (!student) return res.status(404).json({ message: "Student not found" });

    student.mobile = mobile || student.mobile;
    student.address = address || student.address;
    student.tenthMarks = tenthMarks || student.tenthMarks;
    student.twelfthMarks = twelfthMarks || student.twelfthMarks;
    student.skills = skills || student.skills;
    student.aggregate = aggregate || student.aggregate;
    if (profilePic) student.profilePic = profilePic;

    await student.save();

    res.json({ message: "Profile updated successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ View Notifications Sent by TPO
exports.viewNotifications = async (req, res) => {
  try {
    const student = await Student.findOne({ userId: req.user.id });

    if (!student) return res.status(404).json({ message: "Student not found" });

    res.json({ notifications: student.notifications || [] });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};







// ✅ Compare Student Skills with Company Recommended Skills
exports.matchStudentSkills = async (req, res) => {
  try {
    // 🔍 1. Find the student using `userId`
    const student = await Student.findOne({ userId: req.user.id });

    if (!student) {
      return res.status(404).json({ success: false, message: "Student not found" });
    }

    // 🔍 2. Fetch all companies
    const companies = await Company.find();

    if (!companies || companies.length === 0) {
      return res.status(404).json({ success: false, message: "No companies found" });
    }

    // ✅ Extract student skills (Ensure it's an array)
    const studentSkills = student.skills || [];

    // ✅ Fetch all jobs separately from the Job collection
    const jobs = await Job.find();

    if (!jobs || jobs.length === 0) {
      return res.status(404).json({ success: false, message: "No jobs found" });
    }

    const jobMatches = [];

    jobs.forEach(job => {
      const recommendedSkills = job.recommendedSkills || [];

      // ✅ Find matched and missing skills
      const matchedSkills = studentSkills.filter(skill => recommendedSkills.includes(skill));
      const missingSkills = recommendedSkills.filter(skill => !studentSkills.includes(skill));

      jobMatches.push({
        companyName: job.companyName,
        jobTitle: job.title,
        recommendedSkills,
        matchedSkills,
        missingSkills,
      });
    });

    res.json({
      success: true,
      studentSkills,
      jobMatches,
    });

  } catch (error) {
    console.error("❌ Error matching skills:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};