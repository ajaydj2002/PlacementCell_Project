const express = require("express");
const multer = require("multer");
const {
  addSkillsAndAggregate,
  viewSchedule,
  viewJobs,
  updateProfile,
  viewNotifications,
  matchStudentSkills
} = require("../controllers/studentController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// ✅ Multer Storage Configuration for Profile Picture
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Store images in 'uploads/' directory
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});
const upload = multer({ storage });

// ✅ Add Skills & Aggregate
router.post("/add-skills", authMiddleware, addSkillsAndAggregate);

// ✅ View Schedule by Date (Uploaded by TPO)
router.get("/view-schedule", authMiddleware, viewSchedule);

// ✅ View Companies and Job Details (Uploaded by Companies)
router.get("/view-jobs", authMiddleware, viewJobs);

// ✅ Update Student Profile (With Profile Picture Upload)
router.put("/update-profile", authMiddleware, upload.single("profilePic"), updateProfile);

// ✅ View Notifications (Sent by TPO)
router.get("/view-notifications", authMiddleware, viewNotifications);

router.get("/match-skills", authMiddleware, matchStudentSkills);

module.exports = router;
