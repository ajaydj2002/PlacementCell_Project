const express = require("express");
const multer = require("multer");
const { register, login } = require("../controllers/authController");

const router = express.Router();

// ✅ Multer Storage Configuration for Profile Picture Uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Save images in 'uploads/' folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname); // Unique filename
  }
});
const upload = multer({ storage });

// ✅ Register User (Students & TPO Can Upload Profile Picture)
router.post("/register", upload.single("profilePic"), register);

// ✅ Login User (Same for Student, TPO, Company)
router.post("/login", login);

module.exports = router;
