const express = require("express");
const {
  addCompanyAndSchedule,
  updateCompany,
  notifyStudents,
  blockUnblockStudent,
  deleteStudent,
  deleteCompany,
  filterStudents,
  getAllStudents,
  getAllCompanies,
  addPlacedStudent
} = require("../controllers/tpoController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// ✅ Add Company & Schedule
router.post("/add-company-schedule", authMiddleware, addCompanyAndSchedule);

// ✅ Update Company Details
router.put("/update-company", authMiddleware, updateCompany);

// ✅ Send Notifications to Students
router.post("/notify-students", authMiddleware, notifyStudents);

// ✅ Block or Unblock a Student
router.put("/block-unblock-student", authMiddleware, blockUnblockStudent);

// ✅ Delete a Student
router.delete("/delete-student", authMiddleware, deleteStudent);

// ✅ Delete a Company
router.delete("/delete-company", authMiddleware, deleteCompany);

// ✅ Filter Students by Aggregate
router.post("/filter-students", authMiddleware, filterStudents);

// ✅ Get All Unblocked Students
router.get("/get-students", authMiddleware, getAllStudents);

// ✅ Get All Companies
router.get("/get-companies", authMiddleware, getAllCompanies);

// ✅ Add Placed Student (Photo & Package)
router.post("/add-placed-student", authMiddleware, addPlacedStudent);

module.exports = router;
