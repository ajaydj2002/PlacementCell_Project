const express = require("express");
const { addJob } = require("../controllers/companyController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// ✅ Add a Job with Recommended Skills
router.post("/add-job", authMiddleware, addJob);

module.exports = router;
