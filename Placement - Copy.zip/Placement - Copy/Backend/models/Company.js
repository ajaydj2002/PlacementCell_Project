const mongoose = require("mongoose");

const companySchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },

  // ✅ Schedule Details
  schedule: {
    date: { type: Date, required: true },
    event: { type: String, required: true }
  },

  // ✅ Job Postings
  jobs: [
    { 
      title: { type: String, required: true }, 
      salary: { type: Number, required: true }, 
      location: { type: String, required: true }, 
      jobDescription: { type: String, required: true }, 
      jobType: { type: String, enum: ["Full-time", "Internship"], required: true }, 
      recommendedSkills: [{ type: String, required: true }] 
    }
  ],

  // ✅ Students Associated with the Company
  students: [
    { 
      studentId: { type: mongoose.Schema.Types.ObjectId, ref: "Student" }, 
      name: { type: String, required: true }, 
      skills: [{ type: String }], 
      aggregate: { type: Number }
    }
  ]
});

module.exports = mongoose.model("Company", companySchema);
