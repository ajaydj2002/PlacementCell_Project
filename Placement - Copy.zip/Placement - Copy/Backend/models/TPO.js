const mongoose = require("mongoose");

const tpoSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  notifications: [
    {
      studentId: { type: mongoose.Schema.Types.ObjectId, ref: "Student" },
      message: { type: String, required: true },
      date: { type: Date, default: Date.now }
    }
  ],
  students: [{ type: mongoose.Schema.Types.ObjectId, ref: "Student" }], // ✅ Tracks registered students
  companies: [{ type: mongoose.Schema.Types.ObjectId, ref: "Company" }], // ✅ Tracks registered companies
}, { timestamps: true }); // ✅ Automatically adds createdAt & updatedAt timestamps

module.exports = mongoose.model("TPO", tpoSchema);
