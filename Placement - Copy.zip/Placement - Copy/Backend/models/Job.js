const mongoose = require("mongoose");

const jobSchema = new mongoose.Schema({
  companyName: { type: String, required: true },
  title: { type: String, required: true },
  salary: { type: Number, required: true },
  location: { type: String, required: true },
  jobDescription: { type: String, required: true },
  jobType: { type: String, enum: ["Full-time", "Internship"], required: true },
  recommendedSkills: { type: [String], required: true },
  datePosted: { type: Date, default: Date.now },
});

const Job = mongoose.model("Job", jobSchema);
module.exports = Job;
