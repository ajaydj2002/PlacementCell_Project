const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  profilePic: { type: String },
  mobile: { type: String, required: true },
  address: { type: String, required: true },
  tenthMarks: { type: Number, required: true },
  twelfthMarks: { type: Number, required: true },
  aggregate: { type: Number, default: 0 },
  blocked: { type: Boolean, default: false },
  skills: [{ type: String }],
  schedule: [
    { 
      companyId: { type: mongoose.Schema.Types.ObjectId, ref: "Company" },
      companyName: { type: String, required: true },
      date: { type: Date, required: true },
      event: { type: String, required: true }
    }
  ],
  notifications: [{ message: String, date: { type: Date, default: Date.now } }],
  jobs: [
    {
      companyName: { type: String, required: true },
      title: { type: String, required: true },
      salary: { type: Number, required: true },
      location: { type: String, required: true },
      jobDescription: { type: String, required: true },
      jobType: { type: String, enum: ["Full-time", "Internship"], required: true },
      recommendedSkills: [{ type: String }]
    }
  ]
});

module.exports = mongoose.model("Student", studentSchema);
