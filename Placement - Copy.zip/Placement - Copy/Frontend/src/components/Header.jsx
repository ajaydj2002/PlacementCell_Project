import React, { useState } from "react";
import { Link } from "react-router-dom";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleNavbar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light shadow" style={{ backgroundColor: "white", padding: "10px 20px" }}>
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/" onClick={() => setIsOpen(false)}>PLACEMENT CELL</Link>

        <button className="navbar-toggler" type="button" onClick={toggleNavbar}>
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className={`collapse navbar-collapse ${isOpen ? "show" : ""}`} id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><Link className="nav-link" to="/" onClick={() => setIsOpen(false)}>Home</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/academics" onClick={() => setIsOpen(false)}>Academics</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/student-corner" onClick={() => setIsOpen(false)}>Student Corner</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/facilities" onClick={() => setIsOpen(false)}>Facilities</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/auth" onClick={() => setIsOpen(false)}>Register/Login</Link></li> {/* ✅ Single NavLink */}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;
