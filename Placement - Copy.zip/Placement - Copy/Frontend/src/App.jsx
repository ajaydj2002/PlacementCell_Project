import React from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Home from "./pages/Home";
import Academics from "./pages/Academics";
import StudentCorner from "./pages/StudentCorner"; // New Page Added
import Facilities from "./pages/Facilities"; 


import AuthPage from "./pages/AuthPage";
import StudentDashboard from "./pages/StudentDashboard";
import TPODashboard from "./pages/TPODashboard";
import CompanyDashboard from "./pages/CompanyDashboard";

import ManageCompanies from "./pages/ManageCompanies"; // ✅ New Page for Managing Companies
import ManageStudents from "./pages/ManageStudents"; // ✅ New Page for Managing Students
import TPOFilterStudents from "./pages/TPOFilterStudents";
import RegisterStudent from "./pages/RegisterStudent";
import BlockUnblockStudent from "./pages/BlockUnblockStudent";

// ✅ Add New Pages
import ViewScheduleJobs from "./pages/ViewScheduleJobs";  // ✅ New Page
import ViewNotifications from "./pages/ViewNotifications";  // ✅ New Page
import RecommendedSkills from "./pages/RecommendedSkills"; //
function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/academics" element={<Academics />} />
        <Route path="/student-corner" element={<StudentCorner />} /> {/* ✅ Student Corner Page Added */}
        <Route path="/facilities" element={<Facilities />} /> {/* ✅ Facilities Page Added */}
        <Route path="/auth" element={<AuthPage />} /> {/* ✅ Single NavLink for Register & Login */}

        <Route path="/student-dashboard" element={<StudentDashboard />} />
        <Route path="/tpo-dashboard" element={<TPODashboard />} />
        <Route path="/company-dashboard" element={<CompanyDashboard />} />

        <Route path="/tpo/manage-companies" element={<ManageCompanies />} /> 
        <Route path="/tpo/manage-students" element={<ManageStudents />} />
        <Route path="/tpo/filter-students" element={<TPOFilterStudents />} />
        <Route path="/tpo/register-student" element={<RegisterStudent />} /> 
        <Route path="/tpo/block-unblock-student" element={<BlockUnblockStudent />} />  

        <Route path="/student/view-schedule-jobs" element={<ViewScheduleJobs />} />
        <Route path="/student/view-notifications" element={<ViewNotifications />} /> 
        <Route path="/student/recommended-skills" element={<RecommendedSkills />} />
      </Routes>
    </>
  );
}

export default App;
