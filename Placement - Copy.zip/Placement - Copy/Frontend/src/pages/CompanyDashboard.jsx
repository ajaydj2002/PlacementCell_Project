import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Button,
  Form,
  Toast,
  ToastContainer,
  Spinner,
} from "react-bootstrap";
import { motion } from "framer-motion"; // Animation library
import { FaSignOutAlt, FaBriefcase, FaPlus, FaCheckCircle } from "react-icons/fa";

const CompanyDashboard = () => {
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const [toastVariant, setToastVariant] = useState("success");
  const [newJob, setNewJob] = useState({
    title: "",
    salary: "",
    location: "",
    jobDescription: "",
    jobType: "Full-time",
    recommendedSkills: [],
  });
  const [newSkill, setNewSkill] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // ✅ Redirect if not a company
  useEffect(() => {
    const role = localStorage.getItem("role");
    if (role !== "company") {
      navigate("/auth");
    }
  }, [navigate]);

  // ✅ Handle Adding Skills
  const handleAddSkill = () => {
    if (newSkill.trim() && !newJob.recommendedSkills.includes(newSkill.trim())) {
      setNewJob((prevJob) => ({
        ...prevJob,
        recommendedSkills: [...prevJob.recommendedSkills, newSkill.trim()],
      }));
      setNewSkill("");
    }
  };

  // ✅ Handle Job Submission
  const handleAddJob = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setToastMessage("Unauthorized! Please log in again.");
        setToastVariant("danger");
        setShowToast(true);
        setLoading(false);
        return;
      }

      if (newJob.recommendedSkills.length === 0) {
        setToastMessage("Please add at least one recommended skill.");
        setToastVariant("warning");
        setShowToast(true);
        setLoading(false);
        return;
      }

      // ✅ Convert salary to a number before sending
      const jobData = {
        ...newJob,
        salary: Number(newJob.salary),
      };

      console.log("🔵 Sending Job Data:", jobData); // ✅ Debug log

      const res = await axios.post(
        "http://localhost:5000/api/company/add-job",
        jobData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("🟢 Response from Backend:", res.data); // ✅ Debug log

      if (res.data.success) {
        setToastMessage("Job posted successfully!");
        setToastVariant("success");
        setNewJob({
          title: "",
          salary: "",
          location: "",
          jobDescription: "",
          jobType: "Full-time",
          recommendedSkills: [],
        });
      } else {
        throw new Error("Failed to post job.");
      }
    } catch (error) {
      console.error("🔴 Error Posting Job:", error); // ✅ Debug log
      setToastMessage(error.response?.data?.message || "Failed to post job. Try again.");
      setToastVariant("danger");
    } finally {
      setShowToast(true);
      setLoading(false);
    }
  };

  // ✅ Handle Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/auth");
  };

  return (
    <Container className="mt-5">
      {/* ✅ Toast Popup */}
      <ToastContainer position="top-end" className="p-3">
        <Toast
          show={showToast}
          onClose={() => setShowToast(false)}
          delay={3000}
          autohide
          bg={toastVariant}
        >
          <Toast.Body className="text-white">
            <FaCheckCircle className="me-2" /> {toastMessage}
          </Toast.Body>
        </Toast>
      </ToastContainer>

      <Row className="justify-content-center">
        <Col md={10}>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
            <Card className="shadow-lg p-4">
              <div className="d-flex justify-content-between align-items-center">
                <h3 className="text-primary">
                  <FaBriefcase className="me-2" /> Company Dashboard
                </h3>
                <Button variant="danger" onClick={handleLogout}>
                  <FaSignOutAlt /> Logout
                </Button>
              </div>

              <Card.Body>
                {/* ✅ Job Form */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <Form onSubmit={handleAddJob}>
                    <Form.Group className="mb-3">
                      <Form.Label>Job Title</Form.Label>
                      <Form.Control
                        type="text"
                        value={newJob.title}
                        onChange={(e) => setNewJob({ ...newJob, title: e.target.value })}
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Job Type</Form.Label>
                      <Form.Select
                        value={newJob.jobType}
                        onChange={(e) => setNewJob({ ...newJob, jobType: e.target.value })}
                      >
                        <option value="Full-time">Full-time</option>
                        <option value="Internship">Internship</option>
                      </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Salary / Stipend</Form.Label>
                      <Form.Control
                        type="number"
                        value={newJob.salary}
                        onChange={(e) => setNewJob({ ...newJob, salary: e.target.value })}
                        placeholder="Enter salary or stipend"
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Location</Form.Label>
                      <Form.Control
                        type="text"
                        value={newJob.location}
                        onChange={(e) => setNewJob({ ...newJob, location: e.target.value })}
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Job Description</Form.Label>
                      <Form.Control
                        as="textarea"
                        rows={3}
                        value={newJob.jobDescription}
                        onChange={(e) => setNewJob({ ...newJob, jobDescription: e.target.value })}
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Recommended Skills</Form.Label>
                      <div className="d-flex">
                        <Form.Control
                          type="text"
                          value={newSkill}
                          onChange={(e) => setNewSkill(e.target.value)}
                          placeholder="Enter skill"
                        />
                        <Button variant="primary" className="ms-2" onClick={handleAddSkill}>
                          <FaPlus />
                        </Button>
                      </div>
                      <div className="mt-2">
                        {newJob.recommendedSkills.map((skill, index) => (
                          <span key={index} className="badge bg-secondary me-2">{skill}</span>
                        ))}
                      </div>
                    </Form.Group>

                    <Button variant="primary" type="submit" className="w-100" disabled={loading}>
                      {loading ? <Spinner animation="border" size="sm" /> : "Post Job"}
                    </Button>
                  </Form>
                </motion.div>
              </Card.Body>
            </Card>
          </motion.div>
        </Col>
      </Row>
    </Container>
  );
};

export default CompanyDashboard;
