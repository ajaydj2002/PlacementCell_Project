import React from "react";
import img3 from "../assets/img2.png"; // Student image

const StudentCorner = () => {
  return (
    <div className="container-fluid px-0" style={{ background: "#f8f9fa", minHeight: "100vh" }}>
      
      {/* ✅ Hero Section - Simple and Clean */}
      <div className="text-center p-5"
        style={{
          color: "#333",
          fontSize: "24px",
          fontWeight: "bold",
        }}>
        <h1 className="fw-bold animate__animated animate__fadeInDown">Student Corner</h1>
        <p className="animate__animated animate__fadeInUp">Hear from students about their experiences and placements.</p>
      </div>

      {/* ✅ Testimonial Section */}
      <div className="container mt-5">
        <div className="row align-items-center">
          <div className="col-md-6 text-center animate__animated animate__fadeInLeft">
            <img src={img3} alt="Student" className="img-fluid rounded shadow-lg"
              style={{ width: "80%", height: "350px", objectFit: "cover", borderRadius: "10px" }} />
          </div>
          <div className="col-md-6 animate__animated animate__fadeInRight">
            <h2 className="fw-bold text-dark">Student Experiences</h2>
            <p className="text-muted">Our students have shared their real-life experiences on how our institution has helped shape their careers.</p>
            <blockquote className="blockquote">
              <p>"The placement cell helped me land my dream job at Infosys. The career guidance sessions were invaluable!"</p>
              <footer className="blockquote-footer">John Doe, Computer Science Graduate</footer>
            </blockquote>
          </div>
        </div>
      </div>

    </div>
  );
};

export default StudentCorner;
