import React from "react";
import img1 from "../assets/img4.png"; // First academic image
import img2 from "../assets/img5.png"; // Second academic image

const Academics = () => {
  return (
    <div className="container-fluid px-0" style={{ background: "#f8f9fa", minHeight: "100vh" }}>
      
      {/* ✅ Section 1 - Heading on Left, Image on Right */}
      <div className="container mt-5">
        <div className="row align-items-center">
          <div className="col-md-6 animate__animated animate__fadeInLeft">
            <h1 className="fw-bold" style={{ color: "black" }}>Excellence in Academics</h1>
            <p className="text-muted">
              Empowering students with knowledge, research, and industry expertise. Our academic programs are designed to provide students 
              with a comprehensive learning experience, preparing them for successful careers in various fields.
            </p>
          </div>
          <div className="col-md-6 text-center animate__animated animate__fadeInRight">
            <img 
              src={img1} 
              alt="Academic Learning" 
              className="img-fluid rounded shadow-lg"
              style={{ width: "80%", height: "350px", objectFit: "cover", borderRadius: "10px" }} 
            />
          </div>
        </div>
      </div>

      {/* ✅ Academic Programs Section */}
      <div className="container mt-5">
        <div className="row align-items-center">
          <div className="col-md-6 text-center animate__animated animate__fadeInLeft">
            <img 
              src={img2} 
              alt="Academic Learning" 
              className="img-fluid rounded shadow-lg" 
              style={{ width: "80%", height: "350px", objectFit: "cover", borderRadius: "10px" }} 
            />
          </div>
          <div className="col-md-6 animate__animated animate__fadeInRight">
            <h2 className="fw-bold">Our Programs & Specializations</h2>
            <p>Our institution offers a wide range of programs designed to meet industry standards and equip students with real-world skills:</p>
            <ul className="list-group list-group-flush">
              <li className="list-group-item">• Computer Science & Engineering</li>
              <li className="list-group-item">• Business Administration</li>
              <li className="list-group-item">• Mechanical & Civil Engineering</li>
              <li className="list-group-item">• Biotechnology & Life Sciences</li>
              <li className="list-group-item">• Data Science & Artificial Intelligence</li>
            </ul>
          </div>
        </div>
      </div>

      {/* ✅ Facilities & Learning Environment Section (Heading on Left, Image on Right) */}
      <div className="container mt-5">
        <div className="row align-items-center">
          <div className="col-md-6 animate__animated animate__fadeInLeft">
            <h2 className="fw-bold">State-of-the-Art Infrastructure</h2>
            <p>We provide students with world-class facilities to enhance their learning experience, including:</p>
            <ul className="list-group list-group-flush">
              <li className="list-group-item">• Advanced Computer Labs & Research Centers</li>
              <li className="list-group-item">• Smart Classrooms with Digital Learning</li>
              <li className="list-group-item">• Well-Stocked Library with E-Resources</li>
              <li className="list-group-item">• Innovation & Entrepreneurship Hub</li>
              <li className="list-group-item">• Industry Partnerships & Training Programs</li>
            </ul>
          </div>
          <div className="col-md-6 text-center animate__animated animate__fadeInRight">
            <img 
              src={img1} 
              alt="Academic Infrastructure" 
              className="img-fluid rounded shadow-lg" 
              style={{ width: "80%", height: "350px", objectFit: "cover", borderRadius: "10px" }} 
            />
          </div>
        </div>
      </div>

      {/* ✅ Career Development Section - Shifted to Bottom */}
      <div className="container mt-5 pb-5">
        <div className="text-center animate__animated animate__fadeInUp">
          <h2 className="fw-bold">Career Opportunities & Industry Connections</h2>
          <p className="lead">
            Our placement cell ensures that students are connected with top companies, internships, and real-world projects.
          </p>
        </div>
      </div>
      
    </div>
  );
};

export default Academics;
