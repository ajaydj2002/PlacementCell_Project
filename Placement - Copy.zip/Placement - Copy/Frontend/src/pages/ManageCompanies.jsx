import React, { useState, useEffect } from "react";
import axios from "axios";
import { Container, Row, Col, Card, Button, Table, Alert, Form, Modal } from "react-bootstrap";
import { FaUniversity, FaTrash, FaPencilAlt, FaArrowLeft, FaSave, FaTimes } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const ManageCompanies = () => {
  const navigate = useNavigate();
  const [companies, setCompanies] = useState([]);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [editCompany, setEditCompany] = useState(null); // Company being edited
  const [showModal, setShowModal] = useState(false);

  // ✅ Fetch All Companies
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setMessage({ type: "danger", text: "Unauthorized! Please login again." });
          return;
        }

        const res = await axios.get("http://localhost:5000/api/tpo/get-companies", {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.data.success) {
          setCompanies(res.data.companies);
        } else {
          setMessage({ type: "danger", text: "Failed to fetch companies." });
        }
      } catch (error) {
        setMessage({ type: "danger", text: "Error fetching companies. Try again later." });
      }
    };

    fetchCompanies();
  }, []);

  // ✅ Handle Delete Company
  const handleDeleteCompany = async (companyId) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.delete("http://localhost:5000/api/tpo/delete-company", {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        data: { companyId },
      });

      if (res.status === 200) {
        setMessage({ type: "success", text: "Company deleted successfully!" });
        setCompanies(companies.filter(company => company._id !== companyId));
      } else {
        setMessage({ type: "danger", text: "Failed to delete company." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: "Error deleting company. Try again later." });
    }
  };

  // ✅ Handle Edit Company Click
  const handleEditClick = (company) => {
    setEditCompany({ ...company, scheduleDate: "", scheduleEvent: "" }); // Initialize fields
    setShowModal(true);
  };

  // ✅ Handle Edit Input Change
  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditCompany((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ✅ Handle Save Edited Company
  const handleSaveEdit = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }
  
      const res = await axios.put(
        "http://localhost:5000/api/tpo/update-company",
        {
          companyId: editCompany._id,
          scheduleDate: editCompany.scheduleDate,
          scheduleEvent: editCompany.scheduleEvent,
        },
        {
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        }
      );
  
      console.log("API Response:", res.data); // Debugging: Check API response
  
      if (res.data.success) {
        setMessage({ type: "success", text: "✅ Company updated successfully!" });
  
        // ✅ Update UI without refreshing
        setCompanies(companies.map(company =>
          company._id === editCompany._id ? { ...company, ...editCompany } : company
        ));
  
        setShowEditModal(false); // Close the modal after update
  
        // ✅ Auto-hide popup message after 3 seconds
        setTimeout(() => setMessage({ type: "", text: "" }), 3000);
      } else {
        setMessage({ type: "danger", text: "company updated" });
      }
    } catch (error) {
      console.error("Error updating company:", error);
      setMessage({ type: "danger", text: "Company Updated" });
    }
  };
  

  return (
    <Container className="mt-4">
      <Row className="justify-content-center">
        <Col md={10}>
          <Card className="shadow-lg p-4">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h3 className="text-primary">
                <FaUniversity className="me-2" /> Manage Companies
              </h3>
              <Button variant="secondary" onClick={() => navigate("/tpo-dashboard")}>
                <FaArrowLeft /> Back to Dashboard
              </Button>
            </div>

            {message.text && <Alert variant={message.type}>{message.text}</Alert>}

            <Table striped bordered hover responsive>
              <thead className="table-dark">
                <tr>
                  <th>#</th>
                  <th>Company Name</th>
                  <th>Email</th>
                  <th>Jobs Posted</th>
                  <th>Students Applied</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {companies.length > 0 ? (
                  companies.map((company, index) => (
                    <tr key={company._id}>
                      <td>{index + 1}</td>
                      <td>
                        {company.name}
                        <Button variant="link" size="sm" onClick={() => handleEditClick(company)}>
                          <FaPencilAlt />
                        </Button>
                      </td>
                      <td>{company.email}</td>
                      <td>{company.jobs.length}</td>
                      <td>{company.students.length}</td>
                      <td>
                        <Button variant="danger" size="sm" onClick={() => handleDeleteCompany(company._id)}>
                          <FaTrash /> Delete
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">No companies available</td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Card>
        </Col>
      </Row>

      {/* ✅ Edit Company Modal */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Company Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Company Name</Form.Label>
              <Form.Control type="text" value={editCompany?.name} disabled />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Schedule Date</Form.Label>
              <Form.Control
                type="date"
                name="scheduleDate"
                value={editCompany?.scheduleDate}
                onChange={handleEditChange}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Schedule Event</Form.Label>
              <Form.Control
                type="text"
                name="scheduleEvent"
                value={editCompany?.scheduleEvent}
                onChange={handleEditChange}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            <FaTimes /> Cancel
          </Button>
          <Button variant="primary" onClick={handleSaveEdit}>
            <FaSave /> Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default ManageCompanies;
