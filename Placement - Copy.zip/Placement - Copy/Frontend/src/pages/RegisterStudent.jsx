import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Form, Button, Container, Row, Col, Card, Alert } from "react-bootstrap";
import { FaUserPlus, FaArrowLeft, FaTrash } from "react-icons/fa";

const RegisterStudent = () => {
  const navigate = useNavigate();
  const [placedStudents, setPlacedStudents] = useState([]);
  const [placedStudent, setPlacedStudent] = useState({
    name: "",
    company: "",
    package: "",
    description: "",
    photo: "",
  });
  const [message, setMessage] = useState({ type: "", text: "" });

  // ✅ Load Placed Students from Local Storage
  useEffect(() => {
    const storedStudents = JSON.parse(localStorage.getItem("placedStudents")) || [];
    setPlacedStudents(storedStudents);
  }, []);

  // ✅ Handle Input Changes
  const handleChange = (e) => {
    setPlacedStudent({ ...placedStudent, [e.target.name]: e.target.value });
  };

  // ✅ Handle File Upload
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("photo", file);

    try {
      const res = await axios.post("http://localhost:5000/api/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (res.data.success) {
        setPlacedStudent({ ...placedStudent, photo: res.data.filePath });
      } else {
        setMessage({ type: "danger", text: "⚠️ Failed to upload image!" });
      }
    } catch (error) {
      console.error("Image Upload Error:", error);
      setMessage({ type: "danger", text: "❌ Error uploading image. Try again!" });
    }
  };

  // ✅ Handle Form Submission (Save to Local Storage)
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!placedStudent.name || !placedStudent.company || !placedStudent.package || !placedStudent.description || !placedStudent.photo) {
      setMessage({ type: "danger", text: "⚠️ All fields are required!" });
      return;
    }

    const updatedStudents = [...placedStudents, placedStudent];
    setPlacedStudents(updatedStudents);
    localStorage.setItem("placedStudents", JSON.stringify(updatedStudents));

    setMessage({ type: "success", text: "✅ Placed student added successfully!" });
    setPlacedStudent({ name: "", company: "", package: "", description: "", photo: "" });
  };

  // ✅ Handle Deleting a Specific Student
  const handleDeleteStudent = (index) => {
    const updatedStudents = placedStudents.filter((_, i) => i !== index);
    setPlacedStudents(updatedStudents);
    localStorage.setItem("placedStudents", JSON.stringify(updatedStudents));
  };

  return (
    <Container className="mt-4">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="shadow-lg p-4">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <Button variant="secondary" onClick={() => navigate("/tpo-dashboard")}>
                <FaArrowLeft className="me-2" /> Back to Dashboard
              </Button>
              <h3 className="text-primary fw-bold">
                <FaUserPlus className="me-2" /> Add Placed Student
              </h3>
            </div>

            {message.text && <Alert variant={message.type}>{message.text}</Alert>}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Student Name</Form.Label>
                <Form.Control type="text" name="name" value={placedStudent.name} onChange={handleChange} required />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Company Name</Form.Label>
                <Form.Control type="text" name="company" value={placedStudent.company} onChange={handleChange} required />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Package (in LPA)</Form.Label>
                <Form.Control type="number" name="package" value={placedStudent.package} onChange={handleChange} required />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Description</Form.Label>
                <Form.Control as="textarea" rows={3} name="description" value={placedStudent.description} onChange={handleChange} required />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Upload Student Photo</Form.Label>
                <Form.Control type="file" name="photo" onChange={handleFileUpload} required />
              </Form.Group>

              <Button variant="primary" type="submit" className="w-100">
                Add Student
              </Button>
            </Form>
          </Card>

          {/* ✅ Placed Students List */}
          <Card className="shadow-lg p-4 mt-4">
            <h4 className="text-center">📌 Placed Students</h4>
            {placedStudents.length > 0 ? (
              <ul className="list-group mt-3">
                {placedStudents.map((student, index) => (
                  <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
                    <div className="d-flex align-items-center">
                      <img
                        src={`http://localhost:5000${student.photo}`} // ✅ Load image from backend
                        alt={student.name}
                        className="rounded-circle me-2"
                        style={{ width: "50px", height: "50px", objectFit: "cover" }}
                      />
                      <div>
                        <strong>{student.name}</strong> - {student.company} (₹{student.package} LPA)
                      </div>
                    </div>
                    <Button variant="danger" size="sm" onClick={() => handleDeleteStudent(index)}>
                      <FaTrash /> Delete
                    </Button>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-center mt-3">No students placed yet.</p>
            )}
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default RegisterStudent;
