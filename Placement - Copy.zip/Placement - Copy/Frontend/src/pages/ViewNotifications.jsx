import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col, Card, Button, Alert, ListGroup } from "react-bootstrap";
import { FaArrowLeft, FaBell } from "react-icons/fa";

const ViewNotifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [message, setMessage] = useState({ type: "", text: "" });

  const navigate = useNavigate();

  // ✅ Fetch Student Notifications
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setMessage({ type: "danger", text: "Unauthorized! Please login again." });
          return;
        }

        const res = await axios.get("http://localhost:5000/api/student/view-notifications", {
          headers: { Authorization: `Bearer ${token}` },
        });

        console.log("📢 Notifications Response:", res.data); // Debugging Response

        if (res.data.notifications && res.data.notifications.length > 0) {
          setNotifications(res.data.notifications);
        } else {
          setMessage({ type: "warning", text: "No notifications found." });
        }
      } catch (error) {
        console.error("❌ Error Fetching Notifications:", error);
        setMessage({ type: "danger", text: "Failed to fetch notifications." });
      }
    };

    fetchNotifications();
  }, []);

  return (
    <Container className="mt-4">
      {/* ✅ Back to Dashboard Button */}
      <Button variant="secondary" onClick={() => navigate("/student-dashboard")}>
        <FaArrowLeft /> Back to Dashboard
      </Button>

      <Row className="justify-content-center mt-3">
        <Col md={8}>
          <Card className="shadow-lg p-4">
            <h4 className="text-warning"><FaBell /> Your Notifications</h4>
            
            {message.text && <Alert variant={message.type}>{message.text}</Alert>}

            {/* ✅ Notification List */}
            <ListGroup className="mt-3">
              {notifications.length > 0 ? (
                notifications.map((notification, index) => (
                  <ListGroup.Item key={notification._id} className="d-flex justify-content-between align-items-start">
                    <div>
                      <strong className="text-dark">{notification.message}</strong>
                      <br />
                      <small className="text-muted">
                        <strong>Received:</strong> {new Date(notification.date).toLocaleString()}
                      </small>
                    </div>
                  </ListGroup.Item>
                ))
              ) : (
                <ListGroup.Item className="text-center">No notifications available</ListGroup.Item>
              )}
            </ListGroup>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default ViewNotifications;
