import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useState, useRef } from "react";
import {
  Form,
  Button,
  Container,
  Row,
  Col,
  Card,
  Alert,
  Image,
} from "react-bootstrap";
import { FaUserCircle } from "react-icons/fa"; // Profile Icon

const AuthPage = () => {
  const [isRegister, setIsRegister] = useState(true);
  const [role, setRole] = useState("student"); // Default role = Student
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    mobile: "",
    address: "",
    tenthMarks: "",
    twelfthMarks: "",
    profilePic: null,
  });
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");
  const [preview, setPreview] = useState(null); // Image Preview
  const fileInputRef = useRef(null); // Reference to hidden file input

  // ✅ Toggle between Register & Login
  const toggleForm = () => {
    setIsRegister(!isRegister);
    setRole("student"); // Reset Role for Registration
    setFormData({
      name: "",
      email: "",
      password: "",
      mobile: "",
      address: "",
      tenthMarks: "",
      twelfthMarks: "",
      profilePic: null,
    });
    setPreview(null);
    setMessage("");
  };

  // ✅ Handle Input Change
  const handleChange = (e) => {
    if (e.target.name === "profilePic") {
      const file = e.target.files[0];
      if (file) {
        setFormData({ ...formData, profilePic: file });

        // Generate preview
        const reader = new FileReader();
        reader.onloadend = () => setPreview(reader.result);
        reader.readAsDataURL(file);
      }
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  // ✅ Handle Profile Picture Click
  const handleProfileClick = () => {
    fileInputRef.current.click(); // Trigger file input when profile is clicked
  };

  // ✅ Handle Form Submission (Register & Login)
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isRegister) {
        // ✅ Registration API Call
        const formDataToSend = new FormData();
        for (let key in formData) {
          if (formData[key]) formDataToSend.append(key, formData[key]);
        }
        formDataToSend.append("role", role); // Append role

        await axios.post("http://localhost:5000/api/auth/register", formDataToSend, {
          headers: { "Content-Type": "multipart/form-data" },
        });

        setMessage("✅ Registration Successful! You can now log in.");
        setMessageType("success");
        setIsRegister(false); // Switch to login form after registration
      } else {
        // ✅ Login API Call
        const res = await axios.post("http://localhost:5000/api/auth/login", {
          email: formData.email,
          password: formData.password,
        });

        const token = res.data.token;
        localStorage.setItem("token", token); // Store token

        const decodedToken = jwtDecode(token); // Decode JWT token
        const userRole = decodedToken.role; // Extract role from token

        localStorage.setItem("role", userRole); // Store role in local storage

        // ✅ Redirect Based on User Role
        if (userRole === "student") window.location.href = "/student-dashboard";
        else if (userRole === "tpo") window.location.href = "/tpo-dashboard";
        else if (userRole === "company") window.location.href = "/company-dashboard";
      }
    } catch (error) {
      setMessage("❌ Error: " + (error.response?.data?.message || "Something went wrong"));
      setMessageType("danger");
    }
  };

  return (
    <Container className="d-flex justify-content-center mt-5">
      <Row>
        <Col>
          <Card className="shadow-lg p-4 text-center" style={{ width: "400px" }}>
            {/* ✅ Profile Picture Section (Clickable) */}
            {isRegister && (
              <div className="d-flex flex-column align-items-center mb-3" onClick={handleProfileClick} style={{ cursor: "pointer" }}>
                {preview ? (
                  <Image src={preview} roundedCircle width={80} height={80} />
                ) : (
                  <FaUserCircle size={80} color="#ccc" />
                )}
                <small className="text-muted">Click to upload</small>
              </div>
            )}

            {/* Hidden File Input */}
            <input type="file" name="profilePic" accept="image/*" ref={fileInputRef} style={{ display: "none" }} onChange={handleChange} />

            <Card.Title>{isRegister ? "Register" : "Login"}</Card.Title>
            <Form onSubmit={handleSubmit} encType="multipart/form-data">
              {message && <Alert variant={messageType}>{message}</Alert>}

              {/* ✅ Name Field (Required for Registration) */}
              {isRegister && (
                <Form.Group className="mb-3">
                  <Form.Label>Name</Form.Label>
                  <Form.Control type="text" name="name" value={formData.name} onChange={handleChange} required />
                </Form.Group>
              )}

              <Form.Group className="mb-3">
                <Form.Label>Email</Form.Label>
                <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} required />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" name="password" value={formData.password} onChange={handleChange} required />
              </Form.Group>

              {/* ✅ Role Selection for Registration (Only Student & TPO) */}
              {isRegister && (
                <Form.Group className="mb-3">
                  <Form.Label>Role</Form.Label>
                  <Form.Select name="role" value={role} onChange={(e) => setRole(e.target.value)} required>
                    <option value="student">Student</option>
                    <option value="tpo">TPO</option>
                  </Form.Select>
                </Form.Group>
              )}

              {/* ✅ Student-Only Fields */}
              {isRegister && role === "student" && (
                <>
                  <Form.Group className="mb-3">
                    <Form.Label>Mobile</Form.Label>
                    <Form.Control type="text" name="mobile" value={formData.mobile} onChange={handleChange} required />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Address</Form.Label>
                    <Form.Control type="text" name="address" value={formData.address} onChange={handleChange} required />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>10th Marks</Form.Label>
                    <Form.Control type="number" name="tenthMarks" value={formData.tenthMarks} onChange={handleChange} required />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>12th Marks</Form.Label>
                    <Form.Control type="number" name="twelfthMarks" value={formData.twelfthMarks} onChange={handleChange} required />
                  </Form.Group>
                </>
              )}

              <Button variant={isRegister ? "primary" : "success"} type="submit" className="w-100">
                {isRegister ? "Register" : "Login"}
              </Button>
            </Form>

            <div className="text-center mt-3">
              <Button variant="link" onClick={toggleForm}>
                {isRegister ? " Click to Login" : "Click to Register"}
              </Button>
            </div>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default AuthPage;
