import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col, Table, Button, Alert, Form, Modal } from "react-bootstrap";
import { FaTrash, FaBell, FaArrowLeft } from "react-icons/fa";

const ManageStudents = () => {
  const [students, setStudents] = useState([]);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [selectedStudents, setSelectedStudents] = useState([]); // Store selected students for notification
  const [showModal, setShowModal] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    fetchStudents();
  }, []);

  // ✅ Fetch All Students API
  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.get("http://localhost:5000/api/tpo/get-students", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.success) {
        setStudents(res.data.students);
      } else {
        setMessage({ type: "warning", text: "No students found." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: "Failed to fetch students. Try again later." });
    }
  };

  // ✅ Delete Single Student API
  const handleDeleteStudent = async (studentId) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      await axios.delete("http://localhost:5000/api/tpo/delete-student", {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        data: { studentId },
      });

      setMessage({ type: "success", text: "✅ Student deleted successfully!" });
      setStudents(students.filter(student => student._id !== studentId));

      // Auto-hide message after 3 seconds
      setTimeout(() => setMessage({ type: "", text: "" }), 3000);
    } catch (error) {
      setMessage({ type: "danger", text: "⚠️ Error deleting student." });
    }
  };

  // ✅ Handle Checkbox Select for Notification
  const handleCheckboxChange = (studentId) => {
    setSelectedStudents((prevSelected) =>
      prevSelected.includes(studentId)
        ? prevSelected.filter((id) => id !== studentId)
        : [...prevSelected, studentId]
    );
  };

  // ✅ Open Notification Modal
  const openNotificationModal = () => {
    if (selectedStudents.length === 0) {
      setMessage({ type: "danger", text: "⚠️ Please select at least one student to notify!" });
      return;
    }
    setShowModal(true);
  };

  // ✅ Send Notification to Selected Students API
  const handleSendNotification = async () => {
    if (!notificationMessage.trim()) {
      setMessage({ type: "danger", text: "⚠️ Please enter a message before sending!" });
      return;
    }

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.post(
        "http://localhost:5000/api/tpo/notify-students", // ✅ Corrected API endpoint
        { studentIds: selectedStudents, message: notificationMessage }, // ✅ Corrected Payload
        { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
      );

      if (res.data.success) {
        setMessage({ type: "success", text: "✅ Notification sent successfully!" });
        setNotificationMessage("");
        setShowModal(false);
        setSelectedStudents([]); // Clear selection
      } else {
        setMessage({ type: "danger", text: res.data.message || "⚠️ Failed to send notification." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: "⚠️ Error sending notification." });
    }
  };

  return (
    <Container className="mt-4">
      <Row className="justify-content-center">
        <Col md={10}>
          {/* ✅ Back to Dashboard Button */}
          <div className="d-flex justify-content-between align-items-center mb-3">
            <Button variant="secondary" onClick={() => navigate("/tpo-dashboard")}>
              <FaArrowLeft className="me-2" /> Back to Dashboard
            </Button>
            <h2 className="text-center mb-0">Manage Students</h2>
          </div>

          {message.text && <Alert variant={message.type}>{message.text}</Alert>}

          {/* ✅ Student Table */}
          <Table striped bordered hover responsive>
            <thead className="table-dark">
              <tr>
                <th>#</th>
                <th>Select</th>
                <th>Name</th>
                <th>Email</th>
                <th>Aggregate</th>
                <th>Skills</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {students.length > 0 ? (
                students.map((student, index) => (
                  <tr key={student._id}>
                    <td>{index + 1}</td>
                    {/* ✅ Checkbox only for selecting students to notify */}
                    <td>
                      <Form.Check type="checkbox" onChange={() => handleCheckboxChange(student._id)} />
                    </td>
                    <td>{student.name}</td>
                    <td>{student.email}</td>
                    <td>{student.aggregate}%</td>
                    <td>{student.skills.length > 0 ? student.skills.join(", ") : "No Skills"}</td>
                    {/* ✅ Delete Button in Actions */}
                    <td>
                      <Button variant="danger" size="sm" onClick={() => handleDeleteStudent(student._id)}>
                        <FaTrash /> Delete
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" className="text-center">No students available</td>
                </tr>
              )}
            </tbody>
          </Table>

          {/* ✅ Notify Selected Students Button */}
          <div className="d-flex justify-content-end">
            <Button variant="info" onClick={openNotificationModal}>
              <FaBell /> Notify Selected
            </Button>
          </div>

          {/* ✅ Notification Modal */}
          <Modal show={showModal} onHide={() => setShowModal(false)}>
            <Modal.Header closeButton>
              <Modal.Title>Send Notification</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form.Group className="mb-3">
                <Form.Label>Enter Notification Message</Form.Label>
                <Form.Control 
                  type="text"
                  value={notificationMessage}
                  onChange={(e) => setNotificationMessage(e.target.value)}
                  required
                />
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowModal(false)}>Close</Button>
              <Button variant="success" onClick={handleSendNotification}>
                <FaBell className="me-1" /> Send Notification
              </Button>
            </Modal.Footer>
          </Modal>

        </Col>
      </Row>
    </Container>
  );
};

export default ManageStudents;
