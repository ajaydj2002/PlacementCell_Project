import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col, Card, Button, Table, Alert, Spinner } from "react-bootstrap";
import { FaArrowLeft, FaLightbulb, FaSyncAlt } from "react-icons/fa";

const RecommendedSkills = () => {
  const [studentSkills, setStudentSkills] = useState([]); // Store student skills
  const [jobs, setJobs] = useState([]); // Store jobs with recommended & missing skills
  const [message, setMessage] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(true);
  const [retry, setRetry] = useState(false); // Retry mechanism

  const navigate = useNavigate();

  // ✅ Fetch Matched and Missing Skills from `/api/student/match-skills`
  const fetchSkillsMatch = async () => {
    setLoading(true);
    setMessage({ type: "", text: "" });

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        setLoading(false);
        return;
      }

      const res = await axios.get("http://localhost:5000/api/student/match-skills", {
        headers: { Authorization: `Bearer ${token}` },
      });

      console.log("🔵 API Response:", res.data); // ✅ Debugging

      if (res.data.success) {
        setStudentSkills(res.data.studentSkills || []);
        setJobs(res.data.jobMatches || []);
      } else {
        setMessage({ type: "warning", text: "No skill matches found." });
      }
    } catch (error) {
      console.error("🔴 Error Fetching Skills:", error); // ✅ Debugging
      setMessage({ type: "danger", text: "Failed to fetch skill matches. Please try again." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSkillsMatch();
  }, [retry]);

  return (
    <Container className="mt-4">
      <div className="d-flex justify-content-between">
        <Button variant="secondary" onClick={() => navigate("/student-dashboard")}>
          <FaArrowLeft /> Back to Dashboard
        </Button>
  
      </div>

      <Row className="justify-content-center mt-3">
        <Col md={10}>
          <Card className="shadow-lg p-4">
            <h4 className="text-primary"><FaLightbulb /> Recommended Skills</h4>
            {message.text && <Alert variant={message.type}>{message.text}</Alert>}

            {loading ? (
              <div className="text-center my-4">
                <Spinner animation="border" variant="primary" />
                <p>Loading skills and job recommendations...</p>
              </div>
            ) : (
              <Table striped bordered hover responsive className="mt-3">
                <thead className="table-warning">
                  <tr>
                    <th>#</th>
                    <th>Company Name</th>
                    <th>Job Title</th>
                    <th>Required Skills</th>
                    <th>Matched Skills</th>
                    <th>Skills to Improve</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.length > 0 ? (
                    jobs.map((job, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{job.companyName || "Unknown"}</td>
                        <td>{job.jobTitle || "Not Specified"}</td>
                        <td>
                          {Array.isArray(job.recommendedSkills) && job.recommendedSkills.length > 0 ? (
                            <span className="text-primary">{job.recommendedSkills.join(", ")}</span>
                          ) : (
                            "Not Specified"
                          )}
                        </td>
                        <td>
                          {Array.isArray(job.matchedSkills) && job.matchedSkills.length > 0 ? (
                            <span className="text-success">{job.matchedSkills.join(", ")}</span>
                          ) : (
                            <span className="text-danger">❌ No Skills Matched</span>
                          )}
                        </td>
                        <td>
                          {Array.isArray(job.missingSkills) && job.missingSkills.length > 0 ? (
                            <span className="text-danger">{job.missingSkills.join(", ")}</span>
                          ) : (
                            <span className="text-success">✅ You meet all requirements</span>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="6" className="text-center">No job matches found</td>
                    </tr>
                  )}
                </tbody>
              </Table>
            )}
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default RecommendedSkills;
