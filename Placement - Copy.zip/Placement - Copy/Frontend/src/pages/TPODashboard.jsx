import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Form, Button, Container, Row, Col, Card, Alert } from "react-bootstrap";
import { 
  FaBuilding, FaSignOutAlt, FaUsers, FaUniversity, 
  FaFilter, FaPlus, FaUserPlus, FaUserLock 
} from "react-icons/fa"; // Added icons for new buttons

const TPODashboard = () => {
  const navigate = useNavigate();
  const [message, setMessage] = useState({ type: "", text: "" });

  // ✅ Form State for Adding Company
  const [companyData, setCompanyData] = useState({
    name: "",
    email: "",
    password: "",
    scheduleDate: "",
    scheduleEvent: "",
  });

  // ✅ Redirect if not logged in as TPO
  useEffect(() => {
    const role = localStorage.getItem("role");
    if (role !== "tpo") {
      navigate("/auth");
    }
  }, [navigate]);

  // ✅ Handle Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/auth");
  };

  // ✅ Handle Input Changes
  const handleChange = (e) => {
    setCompanyData({ ...companyData, [e.target.name]: e.target.value });
  };

  // ✅ Function to Add a Company
  const handleAddCompany = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.post("http://localhost:5000/api/tpo/add-company-schedule", companyData, {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      });

      if (res.data.success) {
        setMessage({ type: "success", text: "✅ Company registered successfully!" });
        setCompanyData({ name: "", email: "", password: "", scheduleDate: "", scheduleEvent: "" });
      } else {
        setMessage({ type: "danger", text: res.data.message || "⚠️ Failed to register company. Try again." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: error.response?.data?.message || "❌ Server error. Try again later." });
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={10}>
          <Card className="shadow-lg p-4 rounded-4">
            {/* ✅ Header Section */}
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h3 className="text-primary fw-bold">
                <FaBuilding className="me-2" /> TPO Dashboard
              </h3>
              <Button variant="danger" onClick={handleLogout}>
                <FaSignOutAlt className="me-2" /> Logout
              </Button>
            </div>

            <Card.Body>
              {message.text && <Alert variant={message.type}>{message.text}</Alert>}

              {/* ✅ Manage System Section */}
              <h4 className="text-dark text-center mb-3">Manage System</h4>
              <Row className="g-3 mb-4">
                <Col md={4}>
                  <Button
                    variant="info"
                    className="w-100 py-3"
                    onClick={() => navigate("/tpo/manage-companies")}
                  >
                    <FaUniversity className="me-2" /> Manage Companies
                  </Button>
                </Col>
                <Col md={4}>
                  <Button
                    variant="success"
                    className="w-100 py-3"
                    onClick={() => navigate("/tpo/manage-students")}
                  >
                    <FaUsers className="me-2" /> Manage Students
                  </Button>
                </Col>
                <Col md={4}>
                  <Button
                    variant="primary"
                    className="w-100 py-3"
                    onClick={() => navigate("/tpo/filter-students")}
                  >
                    <FaFilter className="me-2" /> Filter Students
                  </Button>
                </Col>
              </Row>

              {/* ✅ New TPO Actions Section */}
              <h4 className="text-dark text-center mb-3">TPO Actions</h4>
              <Row className="g-3 mb-4">
                <Col md={6}>
                  <Button
                    variant="warning"
                    className="w-100 py-3"
                    onClick={() => navigate("/tpo/register-student")}
                  >
                    <FaUserPlus className="me-2" /> Register Student
                  </Button>
                </Col>
                <Col md={6}>
                  <Button
                    variant="danger"
                    className="w-100 py-3"
                    onClick={() => navigate("/tpo/block-unblock-student")}
                  >
                    <FaUserLock className="me-2" /> Block / Unblock Student
                  </Button>
                </Col>
              </Row>

              {/* ✅ Register Company Section */}
              <h4 className="text-dark text-center mt-4 mb-3">Register a Company</h4>
              <p className="text-muted text-center">Add new companies for upcoming placement drives.</p>

              <Form onSubmit={handleAddCompany}>
                <Row className="g-3">
                  <Col md={6}>
                    <Form.Group>
                      <Form.Label>Company Name</Form.Label>
                      <Form.Control type="text" name="name" value={companyData.name} onChange={handleChange} required />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group>
                      <Form.Label>Company Email</Form.Label>
                      <Form.Control type="email" name="email" value={companyData.email} onChange={handleChange} required />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group>
                      <Form.Label>Password</Form.Label>
                      <Form.Control type="password" name="password" value={companyData.password} onChange={handleChange} required />
                    </Form.Group>
                  </Col>
                  <Col md={3}>
                    <Form.Group>
                      <Form.Label>Placement Date</Form.Label>
                      <Form.Control type="date" name="scheduleDate" value={companyData.scheduleDate} onChange={handleChange} required />
                    </Form.Group>
                  </Col>
                  <Col md={3}>
                    <Form.Group>
                      <Form.Label>Event Name</Form.Label>
                      <Form.Control type="text" name="scheduleEvent" value={companyData.scheduleEvent} onChange={handleChange} required />
                    </Form.Group>
                  </Col>
                </Row>

                <div className="d-flex justify-content-center mt-4">
                  <Button variant="primary" type="submit" className="w-50 py-3">
                    <FaPlus className="me-2" /> Register Company
                  </Button>
                </div>
              </Form>

            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default TPODashboard;
