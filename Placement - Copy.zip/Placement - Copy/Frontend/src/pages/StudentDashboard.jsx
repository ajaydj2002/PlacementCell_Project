import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col, Card, Button, Alert, Form, Image } from "react-bootstrap";
import { FaSignOutAlt, FaBell, FaCalendarAlt, FaLightbulb } from "react-icons/fa";

const StudentDashboard = () => {
  const [skillsData, setSkillsData] = useState({ skills: [], aggregate: "" });
  const [message, setMessage] = useState({ type: "", text: "" });
  const [profilePic, setProfilePic] = useState(null);

  const navigate = useNavigate();

  // ✅ Load Profile Picture from LocalStorage
  useEffect(() => {
    const storedProfilePic = localStorage.getItem("profilePic");
    if (storedProfilePic) {
      setProfilePic(`http://localhost:5000${storedProfilePic}`); // Adjust URL if needed
    }
  }, []);

  // ✅ Handle Input Changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSkillsData((prevData) => ({
      ...prevData,
      [name]: name === "skills" ? value.split(",").map((skill) => skill.trim()) : value,
    }));
  };

  // ✅ Handle Save Skills
  const handleSaveSkills = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.post(
        "http://localhost:5000/api/student/add-skills",
        {
          skills: skillsData.skills,
          aggregate: Number(skillsData.aggregate),
        },
        {
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        }
      );

      if (res.data.success) {
        setMessage({ type: "success", text: "Profile added successfully!" });

        // ✅ Reset Form
        setSkillsData({ skills: [], aggregate: "" });

        // ✅ Auto-hide popup after 3 seconds
        setTimeout(() => setMessage({ type: "", text: "" }), 3000);
      } else {
        setMessage({ type: "danger", text: res.data.message || "Failed to add profile." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: "Server error. Try again later." });
    }
  };

  // ✅ Handle Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("profilePic");
    navigate("/auth");
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="shadow-lg p-4">
            {/* ✅ Top Bar with Profile Picture & Logout Button */}
            <div className="d-flex justify-content-between align-items-center">
              <h3 className="text-primary">Student Dashboard</h3>
              <div className="d-flex align-items-center">
                {/* ✅ Profile Picture */}
                {profilePic ? (
                  <Image
                    src={profilePic}
                    roundedCircle
                    width={40}
                    height={40}
                    className="me-3"
                  />
                ) : null}
                <Button variant="danger" onClick={handleLogout}>
                  <FaSignOutAlt /> Logout
                </Button>
              </div>
            </div>

            <Card.Body>
              {message.text && <Alert variant={message.type}>{message.text}</Alert>}

              {/* ✅ Profile Form (Add Skills & Aggregate) */}
              <h4 className="text-dark text-center">Add Your Skills & Aggregate</h4>
              <p className="text-muted text-center">Enter your skills and aggregate percentage.</p>

              <Form onSubmit={handleSaveSkills} className="border p-4 rounded">
                <Form.Group className="mb-3">
                  <Form.Label>Skills (comma-separated)</Form.Label>
                  <Form.Control
                    type="text"
                    name="skills"
                    value={skillsData.skills.join(", ")}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Aggregate (%)</Form.Label>
                  <Form.Control
                    type="number"
                    name="aggregate"
                    value={skillsData.aggregate}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Button variant="primary" type="submit" className="w-100">
                  Save Profile
                </Button>
              </Form>

              <hr />

              {/* ✅ Navigation Buttons */}
              <div className="d-flex justify-content-between">
                <Button variant="info" onClick={() => navigate("/student/view-schedule-jobs")}>
                  <FaCalendarAlt className="me-2" /> View Schedule & Jobs
                </Button>
                <Button variant="warning" onClick={() => navigate("/student/view-notifications")}>
                  <FaBell className="me-2" /> View Notifications
                </Button>
              </div>

              {/* ✅ New Recommended Skills Button */}
              <div className="text-center mt-3">
                <Button variant="success" onClick={() => navigate("/student/recommended-skills")}>
                  <FaLightbulb className="me-2" /> Recommended Skills
                </Button>
              </div>

            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default StudentDashboard;
