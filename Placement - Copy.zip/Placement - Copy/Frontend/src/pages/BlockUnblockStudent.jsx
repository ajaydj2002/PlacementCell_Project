import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col, Table, Button, Alert } from "react-bootstrap";
import { FaArrowLeft, FaUserLock, FaUserCheck } from "react-icons/fa";

const BlockUnblockStudent = () => {
  const [students, setStudents] = useState([]);
  const [message, setMessage] = useState({ type: "", text: "" });
  const navigate = useNavigate();

  useEffect(() => {
    fetchStudents();
  }, []);

  // ✅ Fetch All Students
  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.get("http://localhost:5000/api/tpo/get-students", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.success) {
        setStudents(res.data.students);
      } else {
        setMessage({ type: "warning", text: "No students found." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: "Failed to fetch students. Try again later." });
    }
  };

  // ✅ Block/Unblock Student
  const handleBlockUnblock = async (studentId, action) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      const res = await axios.put(
        "http://localhost:5000/api/tpo/block-unblock-student",
        { studentId, action },
        { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
      );

      if (res.status === 200) {
        setMessage({ type: "success", text: `Student ${action}ed successfully!` });

        // ✅ Update the student's blocked status in UI
        setStudents(students.map(student =>
          student._id === studentId ? { ...student, blocked: action === "block" } : student
        ));
      } else {
        setMessage({ type: "danger", text: "Failed to update student status." });
      }
    } catch (error) {
      setMessage({ type: "danger", text: "Error updating student status." });
    }
  };

  return (
    <Container className="mt-4">
      <Row className="justify-content-center">
        <Col md={10}>
          {/* ✅ Back to Dashboard Button */}
          <div className="d-flex justify-content-between align-items-center mb-3">
            <Button variant="secondary" onClick={() => navigate("/tpo-dashboard")}>
              <FaArrowLeft className="me-2" /> Back to Dashboard
            </Button>
            <h2 className="text-center mb-0">Block / Unblock Students</h2>
          </div>

          {message.text && <Alert variant={message.type}>{message.text}</Alert>}

          {/* ✅ Student Table */}
          <Table striped bordered hover responsive>
            <thead className="table-dark">
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Aggregate</th>
                <th>Skills</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {students.map((student, index) => (
                <tr key={student._id} className={student.blocked ? "bg-light text-muted" : ""}>
                  <td>{index + 1}</td>
                  {student.blocked ? (
                    <>
                      <td colSpan="5" className="text-center fw-bold">
                        Student details are hidden (Blocked)
                      </td>
                    </>
                  ) : (
                    <>
                      <td>{student.name}</td>
                      <td>{student.email}</td>
                      <td>{student.mobile}</td>
                      <td>{student.aggregate}%</td>
                      <td>{student.skills.length > 0 ? student.skills.join(", ") : "No Skills"}</td>
                    </>
                  )}
                  <td>
                    {student.blocked ? (
                      <Button
                        variant="success"
                        size="sm"
                        onClick={() => handleBlockUnblock(student._id, "unblock")}
                      >
                        <FaUserCheck /> Unblock
                      </Button>
                    ) : (
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => handleBlockUnblock(student._id, "block")}
                      >
                        <FaUserLock /> Block
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Col>
      </Row>
    </Container>
  );
};

export default BlockUnblockStudent;
