import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col, Card, Button, Table, Alert, Spinner } from "react-bootstrap";
import { FaArrowLeft, FaBuilding, FaCalendarAlt } from "react-icons/fa";

const ViewScheduleJobs = () => {
  const [schedules, setSchedules] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loadingSchedule, setLoadingSchedule] = useState(true);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [message, setMessage] = useState({ type: "", text: "" });

  const navigate = useNavigate();

  // ✅ Fetch All Company Schedules
  useEffect(() => {
    const fetchSchedules = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setMessage({ type: "danger", text: "Unauthorized! Please login again." });
          return;
        }

        const res = await axios.get("http://localhost:5000/api/student/view-schedule", {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.data.schedules && res.data.schedules.length > 0) {
          setSchedules(res.data.schedules);
        } else {
          setMessage({ type: "warning", text: "No schedules found." });
        }
      } catch (error) {
        console.error("Error fetching schedules:", error);
        setMessage({ type: "danger", text: "Failed to fetch schedules." });
      } finally {
        setLoadingSchedule(false);
      }
    };

    fetchSchedules();
  }, []);

  // ✅ Fetch All Available Jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setMessage({ type: "danger", text: "Unauthorized! Please login again." });
          return;
        }

        const res = await axios.get("http://localhost:5000/api/student/view-jobs", {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.data.jobs && res.data.jobs.length > 0) {
          setJobs(res.data.jobs);
        } else {
          setMessage({ type: "warning", text: "No jobs available." });
        }
      } catch (error) {
        console.error("Error fetching jobs:", error);
        setMessage({ type: "danger", text: "Failed to fetch jobs." });
      } finally {
        setLoadingJobs(false);
      }
    };

    fetchJobs();
  }, []);

  return (
    <Container className="mt-4">
      <Button variant="secondary" onClick={() => navigate("/student-dashboard")}>
        <FaArrowLeft /> Back to Dashboard
      </Button>

      <Row className="justify-content-center mt-3">
        <Col md={10}>
          <Card className="shadow-lg p-4">
            <h4 className="text-primary"><FaCalendarAlt /> Placement Schedules</h4>
            {message.text && <Alert variant={message.type}>{message.text}</Alert>}

            {loadingSchedule ? (
              <div className="text-center my-3">
                <Spinner animation="border" variant="primary" />
                <p>Loading schedules...</p>
              </div>
            ) : (
              <Table striped bordered hover responsive className="mt-3">
                <thead className="table-primary">
                  <tr>
                    <th>#</th>
                    <th>Company Name</th>
                    <th>Date</th>
                    <th>Event</th>
                  </tr>
                </thead>
                <tbody>
                  {schedules.length > 0 ? (
                    schedules.map((event, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{event.companyName || "Unknown"}</td>
                        <td>{event.date ? new Date(event.date).toLocaleDateString() : "Not Available"}</td>
                        <td>{event.event || "No Event"}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4" className="text-center">No schedules available</td>
                    </tr>
                  )}
                </tbody>
              </Table>
            )}

            <h4 className="text-success mt-4"><FaBuilding /> Available Jobs</h4>

            {loadingJobs ? (
              <div className="text-center my-3">
                <Spinner animation="border" variant="success" />
                <p>Loading jobs...</p>
              </div>
            ) : (
              <Table striped bordered hover responsive className="mt-3">
                <thead className="table-success">
                  <tr>
                    <th>#</th>
                    <th>Company</th>
                    <th>Job Title</th>
                    <th>Salary</th>
                    <th>Skills Required</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.length > 0 ? (
                    jobs.map((job, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{job.companyName || "Unknown Company"}</td>
                        <td>{job.title}</td>
                        <td>₹{job.salary?.toLocaleString() || "Not Available"}</td>
                        <td>{job.recommendedSkills?.length > 0 ? job.recommendedSkills.join(", ") : "Not Specified"}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5" className="text-center">No jobs available</td>
                    </tr>
                  )}
                </tbody>
              </Table>
            )}
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default ViewScheduleJobs;
