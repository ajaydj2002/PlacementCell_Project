import React, { useState, useEffect } from "react";
import Homeimg from "../assets/Home.jpg";
import accenture from "../assets/accenture.png";
import cognizant from "../assets/congnizant.png";
import infosys from "../assets/infosys.png";
import tcs from "../assets/tcs.png";
import tech from "../assets/Tech Mahindra.logo.png";
import wipro from "../assets/wipro.png";

const Home = () => {
  const [placedStudents, setPlacedStudents] = useState([]);

  useEffect(() => {
    const storedStudents = JSON.parse(localStorage.getItem("placedStudents")) || [];
    setPlacedStudents(storedStudents);
  }, []);

  return (
    <div className="container mt-5 pt-5">
      {/* ✅ Section 1 - About Placement Cell */}
      <div className="row align-items-center mt-5">
        <div className="col-md-6 text-center">
          <img src={Homeimg} alt="About Us" className="img-fluid rounded shadow" />
        </div>
        <div className="col-md-6">
          <h2 className="fw-bold">Welcome to Placement Cell</h2>
          <p className="text-muted">
            We help students connect with top companies and build successful careers. 
            Our placement training and industry collaborations provide the best opportunities for students to excel in their careers.
          </p>
        </div>
      </div>

      {/* ✅ Section 2 - Top Recruiting Companies */}
      <h2 className="fw-bold text-center mt-5">Top Recruiting Companies</h2>
      <div className="d-flex justify-content-center flex-wrap mt-3">
        {[accenture, cognizant, infosys, tcs, tech, wipro].map((company, index) => (
          <img key={index} src={company} alt="Company" className="m-3" style={{ width: "150px", height: "auto" }} />
        ))}
      </div>

      {/* ✅ Section 3 - Placed Students */}
      <h2 className="fw-bold text-center mt-5">Placed Students</h2>
      <div className="row mt-4">
        {placedStudents.length > 0 ? (
          placedStudents.map((student, index) => (
            <div key={index} className="col-md-3 text-center mb-4">
              {/* ✅ Load image from the correct backend path */}
              <img
                src={`http://localhost:5000${student.photo}`} 
                alt={student.name}
                className="img-fluid  shadow mb-2"
                style={{ width: "150px", height: "150px", objectFit: "cover" }}
              />
              <h5 className="fw-bold">{student.name}</h5>
              <p className="fw-bold" style={{ color: "red" }}>Company Name: {student.company}</p>
              <p className="fw-bold text-success">₹ {student.package} LPA</p>
              <p className="fw-bold">{student.description}</p>
            </div>
          ))
        ) : (
          <p className="text-center">No students placed yet.</p>
        )}
      </div>
    </div>
  );
};

export default Home;
