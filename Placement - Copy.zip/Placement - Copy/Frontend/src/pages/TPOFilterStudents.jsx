import React, { useState } from "react";
import axios from "axios";
import { Container, Row, Col, Card, Button, Alert, Form, Table } from "react-bootstrap";
import { FaFilter, FaArrowLeft } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const TPOFilterStudents = () => {
  const [minAggregate, setMinAggregate] = useState("");
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false); // Added Loading State
  const [message, setMessage] = useState({ type: "", text: "" });

  const navigate = useNavigate();

  // ✅ Handle Filter Students API Call (POST Request)
  const handleFilterStudents = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setMessage({ type: "danger", text: "Unauthorized! Please login again." });
        return;
      }

      if (!minAggregate || isNaN(minAggregate) || minAggregate <= 0) {
        setMessage({ type: "warning", text: "Please enter a valid aggregate percentage." });
        return;
      }

      setLoading(true); // Show loading state

      // ✅ Correct POST request with JSON body
      const res = await axios.post(
        "http://localhost:5000/api/tpo/filter-students",
        { minAggregate: Number(minAggregate) }, // Send in request body
        { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
      );

      console.log("✅ API Response (Filtered Students):", res.data);

      if (Array.isArray(res.data.students) && res.data.students.length > 0) {
        setStudents(res.data.students);
        setMessage({ type: "success", text: `Found ${res.data.students.length} students with aggregate >= ${minAggregate}%` });
      } else {
        setStudents([]);
        setMessage({ type: "warning", text: "No students found with the given aggregate." });
      }

      setMinAggregate(""); // ✅ Clear input after search
    } catch (error) {
      console.error("❌ API Error (Filter Students):", error.response);
      setMessage({ type: "danger", text: error.response?.data?.message || "Failed to fetch students. Try again later." });
    } finally {
      setLoading(false); // Hide loading state
    }
  };

  return (
    <Container className="mt-4">
      <Row className="justify-content-center">
        <Col md={10}>
          <Card className="shadow-lg p-4">
            {/* ✅ Header Section */}
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h3 className="text-primary">
                <FaFilter className="me-2" /> Filter Students by Aggregate
              </h3>
              <Button variant="secondary" onClick={() => navigate("/tpo-dashboard")}>
                <FaArrowLeft /> Back to Dashboard
              </Button>
            </div>

            <Card.Body>
              {message.text && <Alert variant={message.type}>{message.text}</Alert>}

              {/* ✅ Filter Students Form */}
              <Form className="mb-4 d-flex">
                <Form.Control
                  type="number"
                  placeholder="Enter Minimum Aggregate (e.g., 60)"
                  value={minAggregate}
                  onChange={(e) => setMinAggregate(e.target.value)}
                  disabled={loading}
                />
                <Button variant="primary" onClick={handleFilterStudents} className="ms-2" disabled={loading}>
                  <FaFilter className="me-1" /> {loading ? "Filtering..." : "Filter"}
                </Button>
              </Form>

              {/* ✅ Filtered Students Table */}
              <Table striped bordered hover responsive>
                <thead className="table-dark">
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Aggregate</th>
                    <th>Skills</th>
                  </tr>
                </thead>
                <tbody>
                  {students.length > 0 ? (
                    students.map((student, index) => (
                      <tr key={student._id}>
                        <td>{index + 1}</td>
                        <td>{student.name}</td>
                        <td>{student.email}</td>
                        <td>{student.aggregate}%</td>
                        <td>{student.skills.length > 0 ? student.skills.join(", ") : "No Skills"}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5" className="text-center text-muted">No students found</td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default TPOFilterStudents;
