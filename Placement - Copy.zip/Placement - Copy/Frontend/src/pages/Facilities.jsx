import React from "react";
import { 
  FaLaptopCode, 
  FaChalkboardTeacher, 
  FaBook, 
  FaBuilding, 
  FaUserGraduate, 
  FaMicroscope, 
  FaNetworkWired, 
  FaBriefcase 
} from "react-icons/fa";

const Facilities = () => {
  // Facilities Data (Array of Objects)
  const facilities = [
    { id: 1, icon: <FaLaptopCode size={70} color="#ff5733" />, title: "Advanced Labs", description: "State-of-the-art computer labs for hands-on learning." },
    { id: 2, icon: <FaChalkboardTeacher size={70} color="#28a745" />, title: "Experienced Faculty", description: "Highly qualified professors for expert guidance." },
    { id: 3, icon: <FaBook size={70} color="#ffc107" />, title: "Library & Resources", description: "Well-stocked library with digital access and study materials." },
    { id: 4, icon: <FaBuilding size={70} color="#17a2b8" />, title: "Modern Infrastructure", description: "Smart classrooms, auditoriums, and comfortable study spaces." },
    { id: 5, icon: <FaUserGraduate size={70} color="#6610f2" />, title: "Student Support", description: "Career counseling, mentorship, and mental health support." },
    { id: 6, icon: <FaMicroscope size={70} color="#e83e8c" />, title: "Research Facilities", description: "Cutting-edge research labs for innovation and development." },
    { id: 7, icon: <FaNetworkWired size={70} color="#fd7e14" />, title: "Industry Collaboration", description: "Strong partnerships with top companies for internships & jobs." },
    { id: 8, icon: <FaBriefcase size={70} color="#20c997" />, title: "Placement Assistance", description: "100% placement support with top multinational companies." }
  ];

  return (
    <div style={{ padding: "50px", background: "#f8f9fa", minHeight: "100vh" }}>
      <h1 style={{ textAlign: "center", fontWeight: "bold", marginBottom: "30px" ,animation: "fadeInDown 1s ease-in-out" }}>
        Our Facilities
      </h1>

      {/* Facilities Grid - 2 Rows, 4 Containers Per Row */}
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "30px" }}>
        {facilities.map((facility, index) => (
          <div key={facility.id} 
            style={{
              width: "320px", 
              height: "280px", 
              background: "white",
              borderRadius: "15px",
              padding: "20px",
              textAlign: "center",
              boxShadow: "0px 5px 20px rgba(0, 0, 0, 0.2)",
              transition: "transform 0.01s ease-in-out, box-shadow 0.3s ease-in-out",
              animation: `fadeInUp 0.5s ease-in-out ${index * 0.1}s both`
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.02)";
              e.currentTarget.style.boxShadow = "0px 10px 25px rgba(0, 0, 0, 0.3)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1)";
              e.currentTarget.style.boxShadow = "0px 5px 20px rgba(0, 0, 0, 0.2)";
            }}
          >
            <div style={{ marginBottom: "15px" }}>{facility.icon}</div>
            <h5 style={{ fontWeight: "bold", fontSize: "18px", marginBottom: "10px" }}>{facility.title}</h5>
            <p style={{ fontSize: "14px", color: "#555" }}>{facility.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Facilities;
